﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Font = System.Drawing.Font;

namespace OrderMaintenance
{
    public partial class OrderEntry : Form
    {
        public OrderEntry()
        {
            InitializeComponent();
            GetOrderId();
            LoadOrderIDs();
        }

        private void LoadOrderIDs()
        {
            cmbOrderIds.DataSource = DataBaseLayer.GetOrderIDs();
            cmbOrderIds.DisplayMember = "OrderId";
            cmbSelectOrderId.DataSource = cmbOrderIds.DataSource;
            cmbSelectOrderId.DisplayMember = "OrderId";

        }

        private void GetOrderId()
        {
            txtOrderId.Text = DataBaseLayer.GetNextOrderID().ToString();
        }

        private void btnCreateOrder_Click(object sender, EventArgs e)
        {
            Order orderdata = new Order()
            {
                OrderID =Convert.ToInt32(txtOrderId.Text),
                OrderData = txtOrderData.Text,
                OrderDate = dateTimePickerOrderDate.Value,
                BuyerName = txtBuyerName.Text,
                ShipTo = txtShipTo.Text
            };
            LoadOrderIDs();
            DataBaseLayer.ExecuteNonQuery(orderdata);
            MessageBox.Show("Order created successfully");
            ClearAll();
        }

        private void ClearAll()
        {
            txtOrderData.Text = string.Empty;
            txtBuyerName.Text = string.Empty;
            txtShipTo.Text = string.Empty;
            dateTimePickerOrderDate.Value = DateTime.Now;
            GetOrderId();
        }

        // Export the record in to pdf
        private bool ExportToPDF(DataTable orderdata)
        {
            try
            {
                var path = System.IO.Path.GetDirectoryName(
                System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
                path = path.Substring(6);
                int i = 0;
                Document pdfdoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);

                PdfWriter.GetInstance(pdfdoc, new FileStream(path + "\\" + "Order_" + orderdata.Rows[0][0].ToString() + ".pdf", FileMode.Create));

                pdfdoc.Open();

                var spacer = new Paragraph("")
                {
                    SpacingAfter = 10f,
                    SpacingBefore = 10f
                };

                pdfdoc.Add(spacer);
                var shiptbl = new PdfPTable(new[] { 5f })
                {
                    HorizontalAlignment = Left,
                    WidthPercentage = 50
                };
                pdfdoc.Add(spacer);
                Paragraph shipto = new Paragraph(new Phrase("ShipTo: "))
                {
                     new Chunk(orderdata.Rows[0][1].ToString())
                };
                pdfdoc.Add(shipto);
                pdfdoc.Add(spacer);
                var ordertbl = new PdfPTable(new[] { .7f, 2f })
                {
                    HorizontalAlignment = Left,
                    WidthPercentage = 75,
                    DefaultCell = { MinimumHeight = 22f }
                };
                //ordertbl.AddCell("OrderID");
                //ordertbl.AddCell(item.OrderID.ToString());
                ordertbl.AddCell("Shipto");
                ordertbl.AddCell(orderdata.Rows[0][1].ToString());
                ordertbl.AddCell("OrderDate");
                ordertbl.AddCell(orderdata.Rows[0][3].ToString());
                ordertbl.AddCell("BuyerName");
                ordertbl.AddCell(orderdata.Rows[0][2].ToString());

                pdfdoc.Add(ordertbl);

                pdfdoc.Add(spacer);
                ReturnSummaryAdd(pdfdoc, orderdata);
                pdfdoc.Close();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        //Multiple return data items
        private void ReturnSummaryAdd(Document pdfdoc,DataTable orderdata)
        {   
            iTextSharp.text.Font fntcolumheader = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 10, 1, iTextSharp.text.BaseColor.BLACK);
            PdfPTable table = new PdfPTable(4);
            for(int i=4;i<orderdata.Columns.Count;i++)
            {
                PdfPCell celltype = new PdfPCell();
                celltype.AddElement(new Chunk(orderdata.Columns[i].ColumnName.ToUpper(), fntcolumheader));
                table.AddCell(celltype);
            }
            for (int i = 0; i < orderdata.Rows.Count; i++)
            {
                for (int j = 4; j < orderdata.Columns.Count; j++)
                {
                    table.AddCell(orderdata.Rows[i][j].ToString());
                }
            }
            pdfdoc.Add(table);
          
        }

        private void ReturnSummaryAdd()
        {
            throw new NotImplementedException();
        }

        private void btnReturnOrder_Click(object sender, EventArgs e)
        {
            ReturnOrder returnOrderdata = new ReturnOrder()
            {
                OrderID = Convert.ToInt32(cmbOrderIds.GetItemText(cmbOrderIds.SelectedItem)),
                ReturnType = txtReturnType.Text,
                ReturnReason = txtReturnReason.Text,
                Comments = txtComments.Text,
                AdditionalComments = txtAdditionalComments.Text
            };
            DataBaseLayer.ExecuteNonQuery(returnOrderdata);            
            MessageBox.Show("Returned Item successfully");
        }

        private void btnGeneratePdf_Click(object sender, EventArgs e)
        {
            var lstorderdetails= DataBaseLayer.GetOrdersData(cmbSelectOrderId.GetItemText(cmbSelectOrderId.SelectedItem));
            if (!ExportToPDF(lstorderdetails))
                return;
            MessageBox.Show("Generated Pdf successfully");
        }
    }
}
