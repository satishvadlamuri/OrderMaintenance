﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderMaintenance
{
    public class ReturnOrder
    {
        public int OrderID { get; set; }
        public string ReturnType { get; set; }
        public string ReturnReason { get; set; }
        public string Comments { get; set; }
        public string AdditionalComments { get; set; }

    }
}
