﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderMaintenance
{
    public class DataBaseLayer
    {
        internal static void ExecuteNonQuery(Order orderdata)
        {
           string OrderQuery= Queries.InsertToOrders(orderdata);

            DBHelper.ExecuteNonQueries(OrderQuery);
        }
        internal static void ExecuteNonQuery(ReturnOrder returnOrdredData)
        {
            string OrderQuery = Queries.InsertToReturnOrders(returnOrdredData);

            DBHelper.ExecuteNonQueries(OrderQuery);
        }

        internal static int GetNextOrderID()
        {
            int i = 0;
            DataTable dt = DBHelper.ExecuteSelect(Queries.SelectOrderID());
            if(dt.Rows.Count==0)
            {
                //intial value of order id
                i = 100000;
            }
            else
            {
                for(int j=dt.Rows.Count-1;j< dt.Rows.Count;j++)
                {
                   i=Convert.ToInt32(dt.Rows[j]["OrderID"].ToString())+1;
                }
            }
            return i;
        }

        internal static DataTable GetOrderIDs()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = DBHelper.ExecuteSelect(Queries.SelectOrderID());
                return dt;
            }
            catch (Exception ex)
            {
                return dt;
            }
        }

        internal static DataTable GetOrdersData(string orderId)
        {
            DataTable dt = new DataTable();
           // List<object> listobj = new List<object>();
            try
            {
                dt = DBHelper.ExecuteSelect(Queries.SelectOrderdata(orderId));
                //foreach (DataRow dr in dt.Rows)
                //{
                //    listobj.Add(dr);
                //}

                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
